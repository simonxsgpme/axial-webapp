<?php $__env->startSection('title', 'Gestion des Permissions'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Liste des Permissions</h5>
                <button type="button" class="btn btn-primary waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#permissionModal" onclick="openCreateModal()">
                    <i class="fi fi-rr-plus me-1"></i> Ajouter une permission
                </button>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nom</th>
                                <th>Slug</th>
                                <th>Date de création</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><span class="fw-semibold"><?php echo e($permission->name); ?></span></td>
                                <td><span class="badge bg-info-subtle text-info"><?php echo e($permission->slug); ?></span></td>
                                <td><?php echo e($permission->created_at->format('d/m/Y H:i')); ?></td>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-icon btn-outline-primary rounded-circle waves-effect waves-light" onclick="openEditModal('<?php echo e($permission->uuid); ?>', '<?php echo e($permission->name); ?>')" data-bs-toggle="tooltip" title="Modifier">
                                        <i class="fi fi-rr-pencil"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-icon btn-outline-danger rounded-circle waves-effect waves-light" onclick="deletePermission('<?php echo e($permission->uuid); ?>')" data-bs-toggle="tooltip" title="Supprimer">
                                        <i class="fi fi-rr-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    <i class="fi fi-rr-key fs-3 d-block mb-2"></i>
                                    Aucune permission trouvée.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Ajout / Modification -->
<div class="modal fade" id="permissionModal" tabindex="-1" aria-labelledby="permissionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="permissionForm" class="sendForm" method="POST" action="<?php echo e(route('settings.permissions.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" id="permissionMethod" value="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="permissionModalLabel">Ajouter une permission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="permissionName" class="form-label">Nom de la permission <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="permissionName" name="name" placeholder="Ex: Gérer les utilisateurs" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary waves-effect" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary waves-effect waves-light">
                        <i class="fi fi-rr-check me-1"></i> <span id="permissionSubmitText">Enregistrer</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function openCreateModal() {
        document.getElementById('permissionModalLabel').textContent = 'Ajouter une permission';
        document.getElementById('permissionSubmitText').textContent = 'Enregistrer';
        document.getElementById('permissionForm').action = "<?php echo e(route('settings.permissions.store')); ?>";
        document.getElementById('permissionMethod').value = 'POST';
        document.getElementById('permissionName').value = '';
    }

    function openEditModal(uuid, name) {
        document.getElementById('permissionModalLabel').textContent = 'Modifier la permission';
        document.getElementById('permissionSubmitText').textContent = 'Mettre à jour';
        document.getElementById('permissionForm').action = "/settings/permissions/" + uuid;
        document.getElementById('permissionMethod').value = 'PUT';
        document.getElementById('permissionName').value = name;

        var modal = new bootstrap.Modal(document.getElementById('permissionModal'));
        modal.show();
    }

    function deletePermission(uuid) {
        Swal.fire({
            icon: 'warning',
            title: 'Confirmation',
            text: 'Voulez-vous vraiment supprimer cette permission ?',
            showDenyButton: true,
            showCancelButton: false,
            confirmButtonText: 'Oui, supprimer',
            denyButtonText: 'Non, annuler',
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '/settings/permissions/' + uuid,
                    type: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function () {
                        loader();
                    },
                    success: function (data) {
                        loader('hide');
                        if (data.success) {
                            sendSuccess(data.message, 'back');
                        } else {
                            SendError(data.message);
                        }
                    },
                    error: function (data) {
                        loader('hide');
                        SendError(data.responseJSON.message ?? 'Une erreur est survenue');
                    }
                });
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\axial-webapp\resources\views/permissions/index.blade.php ENDPATH**/ ?>