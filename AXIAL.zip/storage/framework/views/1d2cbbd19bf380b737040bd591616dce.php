  <script src="<?php echo e(asset('assets/libs/global/global.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/appSettings.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

  <!-- DataTables JS -->
  <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="/assets/js/script.js"></script>
<?php /**PATH C:\laragon\www\axial-webapp\resources\views/partials/scripts.blade.php ENDPATH**/ ?>