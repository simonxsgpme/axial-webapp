<?php $__env->startSection('title', 'Gestion des Utilisateurs'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Liste des Utilisateurs</h5>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-success waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#importModal">
                        <i class="fi fi-rr-file-import me-1"></i> Importer Excel
                    </button>
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary waves-effect waves-light">
                        <i class="fi fi-rr-plus me-1"></i> Ajouter un utilisateur
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="usersTable" class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nom complet</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Rôle</th>
                                <th>Statut</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="avatar avatar-sm">
                                            <?php if($user->avatar): ?>
                                                <img src="<?php echo e(asset('storage/' . $user->avatar)); ?>" alt="" class="rounded-circle">
                                            <?php else: ?>
                                                <span class="avatar-text rounded-circle bg-primary-subtle text-primary fw-bold"><?php echo e(strtoupper(substr($user->first_name, 0, 1) . substr($user->last_name, 0, 1))); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <span class="fw-semibold d-block"><?php echo e($user->full_name); ?></span>
                                            <small class="text-muted"><?php echo e($user->position ?? '-'); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone ?? '-'); ?></td>
                                <td>
                                    <?php if($user->role): ?>
                                        <span class="badge bg-primary-subtle text-primary"><?php echo e($user->role->name); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary-subtle text-secondary">Non défini</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($user->is_active): ?>
                                        <span class="badge bg-success-subtle text-success">Actif</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger">Inactif</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('users.show', $user->uuid)); ?>" class="btn btn-sm btn-icon btn-outline-info rounded-circle waves-effect waves-light" data-bs-toggle="tooltip" title="Voir">
                                        <i class="fi fi-rr-eye"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-icon btn-outline-danger rounded-circle waves-effect waves-light" onclick="deleteUser('<?php echo e($user->uuid); ?>')" data-bs-toggle="tooltip" title="Supprimer">
                                        <i class="fi fi-rr-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted py-4">
                                    <i class="fi fi-rr-users fs-3 d-block mb-2"></i>
                                    Aucun utilisateur trouvé.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal Import Excel -->
<div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form id="importForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel"><i class="fi fi-rr-file-import me-1"></i> Importer des utilisateurs</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info py-2 mb-3">
                        <small><i class="fi fi-rr-info me-1"></i> Le fichier doit contenir les colonnes : <strong>Nom, Prenom, Email</strong> (obligatoires), Telephone, Poste, Sigle_Entite (optionnelles). Format Excel (.xlsx) ou CSV (séparateur: point-virgule).</small>
                    </div>
                    <div class="mb-3">
                        <label for="importFile" class="form-label">Fichier Excel ou CSV <span class="text-danger">*</span></label>
                        <input type="file" class="form-control" id="importFile" name="file" accept=".csv,.txt,.xlsx,.xls" required>
                    </div>
                    <div class="text-center">
                        <a href="<?php echo e(route('users.import.template')); ?>" class="btn btn-sm btn-outline-primary waves-effect">
                            <i class="fi fi-rr-download me-1"></i> Télécharger le modèle Excel
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary waves-effect" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-success waves-effect waves-light">
                        <i class="fi fi-rr-upload me-1"></i> Importer
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Initialize DataTables
    $(document).ready(function() {
        $('#usersTable').DataTable({
            "pageLength": 20,
            "order": [[1, 'asc']], // Tri par nom complet (colonne 1)
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.13.7/i18n/fr-FR.json"
            },
            "columnDefs": [
                {
                    "targets": 0,
                    "searchable": false,
                    "orderable": false,
                    "render": function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                {
                    "targets": -1, // Dernière colonne (Actions)
                    "orderable": false,
                    "searchable": false
                }
            ]
        });
    });

    $('#importForm').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: '<?php echo e(route("users.import")); ?>',
            type: 'POST',
            data: formData,
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function() { loader(); },
            success: function(data) {
                loader('hide');
                if (data.success) {
                    bootstrap.Modal.getInstance(document.getElementById('importModal')).hide();
                    sendSuccess(data.message, data.urlback || 'back');
                } else {
                    SendError(data.message);
                }
            },
            error: function(data) {
                loader('hide');
                SendError(data.responseJSON?.message ?? 'Une erreur est survenue');
            }
        });
    });

    function deleteUser(uuid) {
        Swal.fire({
            icon: 'warning',
            title: 'Confirmation',
            text: 'Voulez-vous vraiment supprimer cet utilisateur ?',
            showDenyButton: true,
            showCancelButton: false,
            confirmButtonText: 'Oui, supprimer',
            denyButtonText: 'Non, annuler',
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '/users/' + uuid,
                    type: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    beforeSend: function () {
                        loader();
                    },
                    success: function (data) {
                        loader('hide');
                        if (data.success) {
                            sendSuccess(data.message, 'back');
                        } else {
                            SendError(data.message);
                        }
                    },
                    error: function (data) {
                        loader('hide');
                        SendError(data.responseJSON.message ?? 'Une erreur est survenue');
                    }
                });
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\axial-webapp\resources\views/users/index.blade.php ENDPATH**/ ?>